package com.pension.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pension.entity.PensionerDetail;

public interface PensionerDetailRepository extends JpaRepository<PensionerDetail, Long>{

}
