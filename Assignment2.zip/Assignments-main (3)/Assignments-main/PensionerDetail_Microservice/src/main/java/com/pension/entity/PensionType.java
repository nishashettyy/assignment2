package com.pension.entity;

public enum PensionType {

	self,family
}
